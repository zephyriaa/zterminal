# Professional Windows UI revision — v2

The user requested the current ZTerminal web application's more professional layout and Apple-inspired design. This supersedes the original large editor-first shell.

Primary review: [Main workstation](https://www.figma.com/design/VtIJq6WBPRJUUKtc4XvnxE?node-id=14-1080).
[Focused research](https://www.figma.com/design/VtIJq6WBPRJUUKtc4XvnxE?node-id=16-1080).
[Preferences](https://www.figma.com/design/VtIJq6WBPRJUUKtc4XvnxE?node-id=18-1080).

## Delivered visual direction

Eight raw, editable Figma capture compositions were added to the existing file. They are not reusable design-system instances yet. The original 35-screen draft and component library remain retained as earlier work; they have not all been migrated to this revision.

| View | Size | Figma node |
|---|---|---|
| Main docked workstation | 1440×900 | 14:1080 |
| Focused research | 1440×900 | 16:1080 |
| Evidence report | 1440×900 | 17:1080 |
| Terminal preferences | 1440×900 | 18:1080 |
| Compact workstation | 1366×768 | 19:1080 |
| Expanded workstation | 1920×1080 | 21:1080 |
| Maximized chart | 1440×900 | 22:1080 |
| Detached chart | 1024×680 | 20:1080 |

## Source-derived layout

The active web route renders FloatingWorkstationShell with ResearchSidebar and a Dockview workspace. Its default layout gives the chart about 70% of the dock's width and puts context above the tabbed research/strategy group in the remaining width.

The revision uses this same compact information architecture: one application header beneath native Windows title controls, a labeled 194px sidebar that collapses to 42px, thin dock separators, group tab strips, an integrated chart toolbar/drawing rail, and right-side context/Python/report groups.

Focused research opens the editor group at a useful height beside the chart. Results retain chart context. Maximized and detached views represent group focus, restore and redock behavior. These are UI designs and local preview interactions, not changes to the native application.

## Materials and typography

Use the actual web Violet tokens: workspace #090A10, panels #14111D, chart #0B0A10, accent #B5A2E8, text #F0EFF5 and muted text #A8A2B5. Use Geist and Geist Mono from the application's font assets.

Apple's [material guidance](https://developer.apple.com/design/human-interface-guidelines/materials) places Liquid Glass in the functional navigation/control layer. The revision uses restrained lavender tint, translucent navigation, small specular highlights, fine separators and matte chart/editor/report surfaces. Preserve green/rose market direction colors separately from the brand accent.

Windows title controls remain native Windows conventions. Do not replace them with macOS traffic lights or require unsupported acrylic over Direct3D chart content.

## Validation evidence

- Source screenshots were inspected for all eight views; chart scale, default dock heights, scrollbars and theme-preview hue were corrected.
- The main imported frame was visually inspected in the actual Figma file.
- Source text uses Geist / Geist Mono; its full UI is DOM text, containers and chart primitives. The only source bitmap is the discrete original logo. No complete-UI raster was imported as the deliverable.
- Local preview sidebar collapse/restore returned widths 42 / 194px.
- Chart maximize/restore hid and restored the companion dock.
- Layout captures use 1366×768, 1440×900, 1920×1080 and detached 1024×680.
- All market and run values are marked design examples. No live data, run execution or broker operation occurs in the preview.
- Native code, releases and deployments remain unchanged.

## Outstanding design-system gate

use_figma is still rejected by the Figma Starter tool quota. The browser session is anonymous and cannot edit/inspect component internals. The supported HTML-to-design capture route completed the visual compositions, but could not fulfill the skill's shared-component and native layer-inspection gates.

When editing access is restored:

1. Inspect each imported root for node types, fonts, image fills, bounds and clipping; confirm primary text and geometry remain editable.
2. Reuse/update the existing library or create web-corresponding header, sidebar, tab, toolbar, input and icon-button families using actual source tokens. Check real font style names before loading them; do not silently substitute Inter.
3. Compose polished views from those instances and bind Geist typography, Violet semantic variables, spacing and radii.
4. Use the captures as references; remove them after their component-based replacements pass structural and visual review.
5. Wire collapse, group focus, detach/redock/restore, strategy/report tabs and preferences interactions into the Figma prototype.
6. Propagate the accepted direction to onboarding, import, run outcomes, indicators, replay, comparison and robustness views from the earlier draft.
7. Complete AA contrast and all view-level visual checks before calling the overall Figma phase complete.

The accepted scope remains UI-first. Native implementation follows completion and review of that design phase.

## Continuation — 7 October 2026

Seventeen additional source views were designed in the same web-aligned direction, covering onboarding, workspace/data libraries, validation, configuration, run states, diagnostics, comparison, robustness, replay, studies, runtime/storage, recovery, provenance, search and handoff. Capture transport completed for nodes 25:1080–41:1080; this does not mean all imports passed review.

First launch (25:1080), datasets (27:1080), configuration (30:1080) and robustness (34:1080) match their sources in Figma canvas inspection. **Baseline comparison (33:1080) is incorrectly populated with diagnostics content and must be repaired before review.** Its local source is correct. Direct editing remains quota-blocked; no additional copies were generated after discovering the mismatch. The remaining imports require individual visual and layer audits.

Source checks covered all seventeen views and four compact workflows. They use semantic text/geometry and the discrete original logo. Long content scrolls within its panel; dialog actions stay fixed. New source navigation includes planned local Workspaces and Datasets entries; these still need propagation to the earlier eight Figma compositions through direct editing.

See [interaction contract](INTERACTION-CONTRACT.md), [capture review map](journey-capture-state.json) and [resume point](RESUME.md) for exact states, capability mappings, DPI notes and remaining gates. Native implementation has not started.

