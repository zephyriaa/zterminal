# Professional web-aligned revision

Source of truth: active `/terminal` route, `FloatingWorkstationShell`, `ResearchSidebar`, the Dockview default layout, and Violet appearance tokens.

The user superseded the original editor-first composition with the current web workstation's layout and Apple-inspired design discipline.

Required changes: compact single header, labeled collapsible navigation, chart-dominant docking, context upper-right and Python/report tabs lower-right, quiet reading surfaces, functional glass, Geist/Geist Mono, restrained lavender accent, native Windows window controls.

This directory contains a local design source for supported Figma capture while `use_figma` remains quota-blocked. It is separate from the application; no runtime or production capability is modified. All market and research examples are explicitly synthetic design examples.

Capture output must remain editable. If native component reuse, variable binding or inspection is blocked, record that limitation and retain this source for completion through `use_figma` after access is restored.

Apple material reference: https://developer.apple.com/design/human-interface-guidelines/materials

Continuation adds `journeys.js` / `journeys.css`: seventeen new design scenarios share the existing shell and tokens. Read `RESUME.md` and `journey-capture-state.json` before using Figma captures; comparison frame 33:1080 has a confirmed import mismatch. The source comparison is correct.

Run the isolated source with `node artifacts/figma-rebuild/revision-v2/server.cjs`, then open `http://127.0.0.1:8765/?view=launch&width=1440&height=900`. These are clickable design examples and perform no native job, file import or provider operation.

