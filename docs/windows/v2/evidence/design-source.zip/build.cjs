const fs = require('fs');
const path = require('path');
const React = require('react');
const { renderToStaticMarkup } = require('react-dom/server');
const lucide = require('lucide-react');
const root = __dirname;
fs.mkdirSync(path.join(root, 'assets'), { recursive: true });
const repo = path.resolve(root, '../../..');
fs.copyFileSync(path.join(repo, 'public/brand/zterminal-mark-v2.png'), path.join(root, 'assets/mark.png'));
for (const [src, dest] of [['geist-latin.woff2', 'geist.woff2'], ['geist-mono-latin.woff2', 'geist-mono.woff2']]) {
  fs.copyFileSync(path.join(repo, 'node_modules/next/dist/next-devtools/server/font', src), path.join(root, 'assets', dest));
}
const icons = {};
for (const name of ['PanelLeftClose','PanelLeftOpen','BarChart3','Layers3','Code2','FlaskConical','Activity','CalendarDays','Settings2','RotateCcw','Search','ChevronDown','ChevronRight','Plus','Minus','X','Square','Maximize2','Minimize2','ExternalLink','MoreHorizontal','Play','Pause','Save','FolderOpen','CircleUserRound','ArrowUpRight','ArrowLeft','MousePointer2','Crosshair','TrendingUp','Type','Ruler','Magnet','Trash2','LayoutGrid','Check','CircleAlert','Database','FileCode2','Download','Eye','Folder','SlidersHorizontal','Move','ChevronLeft']) {
  icons[name] = renderToStaticMarkup(React.createElement(lucide[name], { width: 16, height: 16, strokeWidth: 1.5 }));
}
fs.writeFileSync(path.join(root, 'icons.json'), JSON.stringify(icons));
fs.writeFileSync(path.join(root, 'index.html'), `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>ZTerminal — Web-aligned Windows design / v2</title><link rel="stylesheet" href="style.css"><link rel="stylesheet" href="journeys.css"><script src="https://mcp.figma.com/mcp/html-to-design/capture.js" async></script><script src="journeys.js" defer></script><link rel="stylesheet" href="design-gate.css"><script src="design-gate.js" defer></script><script src="app.js" defer></script></head><body><div id="app" aria-label="ZTerminal Windows design revision"></div></body></html>`);
console.log('Local design source and original product assets prepared.');
