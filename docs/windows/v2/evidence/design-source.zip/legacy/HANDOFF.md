# ZTerminal Windows — Violet Liquid Glass

Figma: https://www.figma.com/design/VtIJq6WBPRJUUKtc4XvnxE
Research studio: https://www.figma.com/design/VtIJq6WBPRJUUKtc4XvnxE?node-id=7-10

## Delivery status

35 editable screen compositions, 45 component masters in seven variant families (including icons), 41 variables, seven text styles and one liquid-glass effect style were created in Figma.

The component review and the 1440×900, 1366×768 research studios plus first-launch composition were inspected as rendered images. A component text-property inheritance defect was corrected and the component review passed its post-fix visual check.

The complete design gate has **not passed**. The Figma Starter MCP quota blocked the final geometry audit, additional screens, prototype wiring, handoff-board creation and remaining visual reviews. No claim is made that the full file is visually verified or that prototype links already work.

The native Windows application was not changed. Implementation follows completion and review of the Figma design.

## File organization

Starter rejected the requested five-page structure. The five named areas are retained across three available pages:

- Direction & foundations: Direction and Foundations sections.
- Components: masters and a separate instance review frame.
- Core screens & handoff: current screens; Prototype & handoff section is prepared but not yet created.

## Product decisions

Research first. Python editing leads; chart context remains beside it. Docked panels can detach into native windows. Presets: Research, Chart Analysis, Results Comparison.

Local use needs no account. Import and explicit permitted provider connections supply verified datasets. Source, data, compute, drafts and run evidence stay local. AI, advanced order flow, GEX and cloud sync remain later milestones.

All prices, code, dataset records, metrics and run outcomes shown are design examples. The Python source illustrates a future UI contract and does not certify currently supported Python API symbols.

## Design tokens

| Semantic role | Value |
|---|---|
| Background | #0B0812 |
| Surface | #171120 |
| Reading surface | #100D18 |
| Elevated surface | #241A35 |
| Accent | #9B6BFF |
| Lavender | #D8C6FF |
| Primary text | #F4EFFA |
| Secondary text | #B6A8C9 |
| Subtle text | #9485A9 |
| Border | #423251 |
| Positive | #64D8B2 |
| Negative | #FF8297 |
| Warning | #F3C878 |
| Accent-button text | #100A1A |

Inter: display 44px, title 28px, heading 18px, body/label 13px, caption 11px; 150% line height.
JetBrains Mono: 12px; compact editor uses 11px.
Spacing: 4, 8, 12, 16, 24, 32.
Corners: controls 8px, panels 12px, dialogs 16px.
Motion: 120, 180, 200ms; reduced motion removes decorative transitions.

Rich glass uses translucent plum, a lavender edge, specular light, restrained refraction and shadows. Code, tables and chart graphics retain stable reading surfaces. Figma's glass effect is a visual direction, not a promise that the native implementation will reproduce its shader. WinUI SwapChainPanel chart surfaces stay opaque; adjacent native chrome uses supported composition APIs and fallback colors.

## Core-screen inventory

See design-system-state.json for every exact screen and node ID. Current coverage:

- Research studio: 1440×900, compact 1366×768 and expanded 1920×1080.
- First launch, workspace library and recovered-draft review.
- Dataset library, import selection, verified preview and rejected import.
- Chart workspace, indicator library, EMA settings, paused/playing replay, provider directory.
- Run configuration and queued/running/cancelled/failed/complete job states.
- Evidence: Overview, Equity, Trades, Diagnostics, Assumptions, Provenance.
- Baseline comparison and Monte Carlo robustness.
- Rich-glass/reduced-effects/opaque settings and unavailable-runtime state.
- Detached chart window.

Pending additional compositions: instrument search, command palette, data/offline states, completed replay and mixed-monitor arrangement.

## Interaction specification

- Title-bar dragging and resize edges manage windows; chart plot gestures manage chart navigation.
- Dock, resize, detach, redock and restore preserve panel identity and drafts.
- Closing a detached window returns its panel to the parent workspace.
- Persist device-independent bounds and monitor identity; recover off-screen windows into a visible work area.
- Symbol, timeframe, crosshair and replay links are opt-in.
- Opening an editor does not create or open a report. Results open only after an immutable run artifact exists or an archive is selected.
- Source/configuration changes remain explicit before a new run.
- Progress comes from engine events. Figma job-state navigation is a review scenario, never production timer logic.
- A failed or cancelled run does not create a completed-result report.
- Incomplete, stale, gap or unavailable data is labelled and affected calculations are withheld.
- Keyboard: Ctrl K command palette; arrows/Enter/Escape operate it. Shortcuts proposed in the design must be reconciled with native commands at implementation.
- Windows 100/150/200% DPI uses logical minima; compact layouts collapse explorers and configuration. High contrast and material-unavailable environments use opaque fallbacks.

## Native contracts and implementation sequence

Reuse canonical target contracts: WorkspaceDocumentV2, ChartDocumentV3, DatasetManifestV3, StrategyRevisionV2, ExperimentRunV2 and ReplayClock. They are planned target contracts, not claims of delivered V2/V3 implementation.

Sequence:
1. C++/WinRT + WinUI 3 shell around the existing Direct3D 11 surface.
2. Durable local workspaces, drafts, docking, detached windows and recovery.
3. Data import/catalogue/provider workflows, charts, indicators, drawings and replay.
4. Native Python editor, diagnostics, supervised asynchronous local jobs and cancellation.
5. Immutable evidence, attributable baseline comparison, Monte Carlo and export.
6. Performance/recovery/accessibility and signed install/update/rollback qualification.

Keep current scene and Helper protocols behind versioned native adapters. Preserve originals during validated reversible migrations. Do not add flagship capabilities to the hosted Tauri preview.

## Remaining acceptance work

- Execute the saved finalization request once Figma access is restored.
- Resolve any missing prototype targets; create five starting points.
- Finish handoff and readiness mapping in Figma.
- Audit bounds, wrapping, component inheritance, variable bindings and placeholder removal.
- Verify normal text ≥4.5:1 and essential interactive boundaries ≥3:1.
- Visually inspect all coherent compositions, especially reports, configuration, appearance fallbacks, import errors and detached/mixed-DPI layouts.
- Correct contextual toolbar actions on launch/library/data/settings screens.
- Correct missing-runtime status labels and any detached-window overflow.
- Review the completed Figma deliverable before native implementation.

## Resume instructions

All request JSON files are for the Figma MCP `use_figma` runtime. They are construction records, not standalone Figma plugins. Do not replay completed creation requests into the populated file.

1. Read design-system-state.json.
2. Inspect the existing file non-destructively and confirm IDs.
3. Execute 07-pending-finalization.request.json, accounting for any user edits since this snapshot.
4. Audit and repair the output; capture affected compositions and report the remaining gates accurately.

No subscription purchase, plan upgrade, native implementation, installer release, deployment or GitHub publication was performed.

