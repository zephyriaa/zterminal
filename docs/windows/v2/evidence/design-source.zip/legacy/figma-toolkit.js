
const createdNodeIds=[],mutatedNodeIds=[];
const D={"createdNodeIds":["3:2","3:3"],"mutatedNodeIds":["0:1"],"pages":{"Direction & foundations":"0:1","Components":"3:2","Core screens & handoff":"3:3"},"collections":{"primitives":"VariableCollectionId:3:4","semantic":"VariableCollectionId:3:5"},"variables":{"background":"VariableID:3:7","surface":"VariableID:3:9","reading":"VariableID:3:11","elevated":"VariableID:3:13","accent":"VariableID:3:15","lavender":"VariableID:3:17","text":"VariableID:3:19","muted":"VariableID:3:21","subtle":"VariableID:3:23","line":"VariableID:3:25","positive":"VariableID:3:27","negative":"VariableID:3:29","warning":"VariableID:3:31","ink":"VariableID:3:33","space/4":"VariableID:3:34","space/8":"VariableID:3:35","space/12":"VariableID:3:36","space/16":"VariableID:3:37","space/24":"VariableID:3:38","space/32":"VariableID:3:39","radius/control":"VariableID:3:40","radius/panel":"VariableID:3:41","radius/dialog":"VariableID:3:42","effects/glass-opacity":"VariableID:3:43","motion/fast-ms":"VariableID:3:44","motion/standard-ms":"VariableID:3:45","motion/slow-ms":"VariableID:3:46"},"styles":{"display":"S:1f54d29c1d0858458832feff926347e634582a25,","title":"S:4a6656a0286a9d89637d583b809ff472a4f5ca4c,","heading":"S:706d67c6837a3955f344e3cba023029bba00fd8e,","body":"S:9a07b68cb63bd4ec3662085acba3c66e31b4a7b5,","label":"S:684acdf5fcefd9be09bd70cda687584ec6842045,","caption":"S:a733fc7a7afc44e9f73543e823856f456ba4a8de,","mono":"S:e20381bacdc307734b403b8252634f9d66b78a69,","glass":"S:ac997b77738e682f49d45f512c0a880c84cde261,"},"variableCount":41,"styleCount":7};
await Promise.all([{family:'Inter',style:'Regular'},{family:'Inter',style:'Medium'},{family:'Inter',style:'Semi Bold'},{family:'Inter',style:'Bold'},{family:'JetBrains Mono',style:'Regular'}].map(f=>figma.loadFontAsync(f)));
const V={};for(const [k,id]of Object.entries(D.variables))V[k]=await figma.variables.getVariableByIdAsync(id);
function keep(n){createdNodeIds.push(n.id);return n;}
function paint(key,opacity=1){return figma.variables.setBoundVariableForPaint({type:'SOLID',color:{r:0,g:0,b:0},opacity},'color',V[key]);}
function radius(n,key='radius/panel'){for(const k of ['topLeftRadius','topRightRadius','bottomLeftRadius','bottomRightRadius'])n.setBoundVariable(k,V[key]);}
function gap(n,value){n.itemSpacing=value;const v=V['space/'+value];if(v)n.setBoundVariable('itemSpacing',v);}
function pad(n,value){for(const k of ['paddingTop','paddingBottom','paddingLeft','paddingRight']){n[k]=value;if(V['space/'+value])n.setBoundVariable(k,V['space/'+value]);}}
function A(name,dir='VERTICAL',w=400,h=null,bg=null,p=0,comp=false){
 const n=keep(comp?figma.createComponent():figma.createAutoLayout(dir));if(comp)n.layoutMode=dir;
 n.name=name;n.resize(w,h||80);n.primaryAxisSizingMode=(dir==='VERTICAL'&&!h)?'AUTO':'FIXED';n.counterAxisSizingMode=(dir==='HORIZONTAL'&&!h)?'AUTO':'FIXED';
 n.fills=bg?[paint(bg)]:[];gap(n,12);pad(n,p);n.clipsContent=false;if(dir==='HORIZONTAL')n.counterAxisAlignItems='CENTER';return n;
}
function T(str,style='body',color='text',w=null){const n=keep(figma.createText());n.name=str.split('\n')[0].slice(0,64);n.textStyleId=D.styles[style];n.characters=str;n.fills=[paint(color)];if(w!==null){n.textAutoResize='HEIGHT';n.resize(w,20);}else n.textAutoResize='WIDTH_AND_HEIGHT';return n;}
function add(p,...ns){for(const n of ns)p.appendChild(n);return p;}
function fill(n,axis='H'){n[axis==='H'?'layoutSizingHorizontal':'layoutSizingVertical']='FILL';return n;}
function line(w,h=1,key='line'){const n=keep(figma.createRectangle());n.name='Divider';n.resize(w,h);n.fills=[paint(key,0.65)];return n;}
function rect(p,x,y,w,h,key='surface',r=0,op=1){const n=keep(figma.createRectangle());p.appendChild(n);n.x=x;n.y=y;n.resize(w,h);n.fills=[paint(key,op)];n.cornerRadius=r;return n;}
function glass(n,opaque=false){n.fills=[paint(opaque?'elevated':'surface',opaque?1:0.78)];n.strokes=[paint('lavender',0.22)];n.strokeWeight=1;radius(n);if(!opaque)n.effectStyleId=D.styles.glass;return n;}
function gradient(n){n.fills=[{type:'GRADIENT_LINEAR',gradientTransform:[[0.78,0.45,0],[0.12,0.94,0]],gradientStops:[{position:0,color:{r:0.22,g:0.1,b:0.37,a:1}},{position:0.52,color:{r:0.065,g:0.04,b:0.1,a:1}},{position:1,color:{r:0.025,g:0.015,b:0.04,a:1}}]}];return n;}
function instance(c,label=null){const n=keep(c.createInstance());for(const child of n.findAll())createdNodeIds.push(child.id);const original=c.findAllWithCriteria({types:['TEXT']}).find(q=>q.name==='Label');const value=label!==null?label:original?.characters;if(value!==undefined){const key=Object.keys(n.componentProperties).find(k=>k.startsWith('Label#'));if(key)n.setProperties({[key]:value});else{const txt=n.findAllWithCriteria({types:['TEXT']}).find(q=>q.name==='Label');if(txt){txt.characters=value;mutatedNodeIds.push(txt.id);}}}return n;}
const C={};if(typeof existingComponentIds!=='undefined')for(const [key,id]of Object.entries(existingComponentIds))C[key]=await figma.getNodeByIdAsync(id);
function B(label,style='secondary'){return instance(C['Button/'+style+'/Default'],label);}
function badge(label,key='Cached'){return instance(C['Status/'+key],label);}
function field(label,value,w=280){const c=A('Field / '+label,'VERTICAL',w);gap(c,8);const n=instance(C['Input/Default'],value);n.resize(w,40);add(c,T(label,'caption','muted'),n);return c;}
function block(title,body,w=400){const c=glass(A(title,'VERTICAL',w,null,null,24));add(c,T(title,'heading'),T(body,'body','muted',w-48));return c;}
function row(name,w,...ns){return add(A(name,'HORIZONTAL',w),...ns);}
function section(name,x,y,w,h){const s=keep(figma.createSection());s.name=name;s.x=x;s.y=y;s.resizeWithoutConstraints(w,h);s.fills=[paint('background')];return s;}
function panel(title,w,h,actions=true){const n=glass(A(title,'VERTICAL',w,h));gap(n,0);const hd=A('Panel header / '+title,'HORIZONTAL',w,44,null,12);const name=T(title,'label');add(hd,name);fill(name);if(actions)add(hd,T('↗   ⋯','body','muted'));const body=A(title+' / content','VERTICAL',w,h-44,'reading',16);radius(body);add(n,hd,body);return {node:n,body,header:hd};}
function graph(name,w,h,kind='candles'){
 const g=keep(figma.createFrame());g.name=name;g.resize(w,h);g.fills=[paint('reading')];g.clipsContent=true;
 for(let j=1;j<5;j++)rect(g,0,j*(h-28)/5,w,1,'line',0,0.4);
 for(let i=1;i<7;i++)rect(g,i*w/7,0,1,h-28,'line',0,0.25);
 if(kind==='candles'){for(let i=0;i<36;i++){const v=(Math.sin(i*0.4)*0.13+Math.sin(i*0.13)*0.2);const base=h*0.53-v*h-i*h*0.004;const hh=10+(i*7%19);const x=14+i*(w-50)/36;const k=i%4===0?'negative':'positive';rect(g,x+3,base-9,1,hh+20,k);rect(g,x,base,7,hh,k,1);rect(g,x,h-46,7,10+(i*13%25),k,0,0.3);}
 }else{
 const pts=[];for(let i=0;i<42;i++){const x=12+i*(w-24)/41;const y=kind==='drawdown'?h*0.28+Math.abs(Math.sin(i*0.23))*h*0.44:h*0.8-i*h*0.012-Math.sin(i*0.51)*h*0.065;pts.push([x,y]);}
 const v=keep(figma.createVector());g.appendChild(v);v.name=kind+' / design example';v.vectorPaths=[{windingRule:'NONE',data:pts.map((p,i)=>(i?'L':'M')+p[0].toFixed(2)+' '+p[1].toFixed(2)).join(' ')}];v.strokes=[paint(kind==='drawdown'?'negative':'accent')];v.strokeWeight=2;
 }
 const lab=T('DESIGN EXAMPLE  ·  cached dataset','caption','muted');g.appendChild(lab);lab.x=12;lab.y=h-22;
 return g;
}
function metric(label,value,detail,w=220,key='text'){const n=glass(A(label,'VERTICAL',w,null,null,16));gap(n,8);add(n,T(label,'caption','muted'),T(value,'title',key),T(detail,'caption','muted',w-32));return n;}
function table(name,w,headers,rows,widths=null){
 const t=A(name,'VERTICAL',w);gap(t,0);const cw=widths||headers.map(()=>Math.floor((w-24)/headers.length));
 function tr(cells,header=false){const r=A(header?'Column headings':'Record','HORIZONTAL',w,header?36:44,header?'elevated':null,12);gap(r,0);for(let i=0;i<cells.length;i++)add(r,T(String(cells[i]),header?'caption':'body',header?'lavender':'text',cw[i]));return r;}
 add(t,tr(headers,true));for(const cells of rows){add(t,tr(cells),line(w));}return t;
}
function shell(name,w=1440,h=900,active='Research'){
 const f=A(name,'VERTICAL',w,h,'background');gradient(f);gap(f,0);figma.currentPage.appendChild(f);
 const head=glass(A('Window chrome','HORIZONTAL',w,48,null,12));radius(head,'radius/control');const z=T('Z','heading','lavender');add(head,z,T('ZTERMINAL','caption','muted'),instance(C['Tab/Selected'],'Mean reversion'),instance(C['Tab/Default'],'BTC research'));const spacer=A('Flexible titlebar','HORIZONTAL',Math.max(40,w-830),24);add(head,spacer,T('Search anything   Ctrl K','caption','muted'),T('—    □    ×','body','muted'));
 const toolbar=A('Workspace toolbar','HORIZONTAL',w,56,null,16);add(toolbar,T(active==='Research'?'Research studio':active,'heading'),badge('LOCAL WORKSPACE','Cached'));const sw=A('Toolbar spacer','HORIZONTAL',Math.max(20,w-920),24);add(toolbar,sw,B('Layout · '+(active==='Research'?'Research':'Chart Analysis')),B('Configure'),B('Run locally','primary'));
 const body=A('Workspace content','HORIZONTAL',w,h-132,null,12);gap(body,12);body.counterAxisAlignItems='MIN';
 const nav=glass(A('Application navigation','VERTICAL',68,h-156,null,8));gap(nav,12);
 for(const [label,ic]of [['Workspaces','layers'],['Research','code'],['Charts','chart'],['Datasets','database'],['Settings','settings']]){
 const item=instance(C['Nav/'+(label===active?'Selected':'Default')]);item.name='Navigate / '+label;
 const icon=item.findAllWithCriteria({types:['INSTANCE']})[0];if(icon&&C['Icon/'+ic]){icon.swapComponent(C['Icon/'+ic]);mutatedNodeIds.push(icon.id);}add(nav,item);
 }add(body,nav);
 const main=A('Main content','VERTICAL',w-104,h-156);gap(main,12);add(body,main);
 const foot=A('Status strip','HORIZONTAL',w,28,'reading',8);gap(foot,24);add(foot,T('●  Local engine ready','caption','positive'),T('Python 3.12  ·  local compute','caption','muted'),T('Design examples — no live prices or actual run results','caption','muted'));
 add(f,head,toolbar,body,foot);return {frame:f,main,toolbar,width:w-104,height:h-156};
}

