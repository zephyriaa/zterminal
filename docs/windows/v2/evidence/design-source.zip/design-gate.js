// Design handoff only. No imports, jobs, native windows or providers run here.
const gateViews=['equity','trades','empty','mixed-monitors','design-review'];
window.researchJourneyViews.push(...gateViews);
window.renderDesignGate=function({app,view,q,icon,tabs}){
  const names={equity:'Equity & drawdown',trades:'Trade inspection',empty:'No completed experiment','mixed-monitors':'Window restoration','design-review':'Native design review'};
  const effect=['rich','reduced','opaque'].includes(q.get('effects'))?q.get('effects'):'rich';
  app.dataset.effects=effect;
  if(Number(app.style.width.replace('px',''))<1100){
    app.classList.add('small-viewport');
    app.querySelector('.sidebar')?.classList.add('collapsed');
  }
  const link=(label,route,primary=false)=>`<button class="button ${primary?'primary':''}" data-view="${route}">${label}</button>`;
  const badge=text=>`<span class="j-badge">${text}</span>`;
  const table=(heads,rows)=>`<div class="gate-table-scroll" tabindex="0" aria-label="Scrollable evidence table"><table class="j-table"><thead><tr>${heads.map(h=>`<th scope="col">${h}</th>`).join('')}</tr></thead><tbody>${rows.map(r=>`<tr>${r.map(c=>`<td>${c}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  const stats=items=>`<div class="j-stats">${items.map(([label,value,sub])=>`<div class="j-stat"><label>${label}</label><strong>${value}</strong><small>${sub}</small></div>`).join('')}</div>`;
  const exampleEquity=[10000,10060,10140,10095,10410,10610,10520,10490,10670,10685,10800,10670,9892.8,10470,10890,10820,11010,11200,11080,11295,11400,11370,11440,11310,11280];
  let peak=exampleEquity[0];
  const exampleDrawdown=exampleEquity.map(value=>{peak=Math.max(peak,value);return (value/peak-1)*100;});
  const paths=(values,{drawdown=false}={})=>{
    const y=value=>10+(drawdown?-value/9:(12000-value)/3000)*185;
    const points=values.map((v,i)=>`${20+i*960/(values.length-1)},${y(v)}`).join(' ');
    const ticks=drawdown?[0,-3,-6,-9]:[12000,11000,10000,9000];
    return `<div class="gate-plot" aria-label="${drawdown?'Drawdown':'Equity'} chart, synthetic design example">${ticks.map(value=>`<div class="gate-grid" style="top:${y(value)/210*87.5}%"><span>${drawdown?value+'%':value.toLocaleString()}</span></div>`).join('')}<svg width="100%" height="100%" viewBox="0 0 1000 210" preserveAspectRatio="none" role="img" aria-label="Illustrative ${drawdown?'drawdown':'equity'} path"><polyline points="${points}" fill="none" stroke="${drawdown?'#fb7185':'#b5a2e8'}" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg><div class="gate-dates"><span>Jan 2026</span><span>Mar</span><span>Jun 2026</span></div></div>`;
  };
  const filters=active=>`<nav class="j-filter" aria-label="Evidence sections">${[['results','Overview'],['equity','Equity & drawdown'],['trades','Trades'],['evidence','Assumptions & provenance']].map(([route,label])=>`<button data-view="${route}" class="${route===active?'active':''}" ${route===active?'aria-current="page"':''}>${label}</button>`).join('')}</nav>`;
  const page=(title,subtitle,body,actions='')=>{
    app.querySelector('.modal-wrap')?.remove();
    app.classList.add('journey-view');
    const dock=app.querySelector('.dock');
    dock.innerHTML=`<section class="group j-page">${tabs([[names[view],'FlaskConical',view]],names[view],false)}<div class="j-content"><div class="j-pagehead"><div><div class="eyebrow">LOCAL RESEARCH · DESIGN EXAMPLE</div><h1>${title}</h1><p>${subtitle}</p></div><div class="grow"></div><div class="row">${actions}</div></div>${body}<div class="j-foot">${badge('DESIGN EXAMPLE')}<span>Synthetic illustrations · no research executed</span></div></div></section>`;
    app.querySelector('.workspace-label').innerHTML=`LOCAL RESEARCH<span>${names[view]}</span>`;
    app.querySelectorAll('.nav .active').forEach(n=>n.classList.remove('active'));
    app.querySelector(`.nav [data-view="${view==='design-review'||view==='mixed-monitors'?'preferences':'results'}"]`)?.classList.add('active');
    app.setAttribute('aria-label',`${names[view]} · design example`);
    document.title=`${names[view]} · ZTerminal design handoff`;
  };
  if(view==='equity'){
    page('Follow the complete path.','Run 013 · revision 3 · completed archived example',`${filters(view)}${stats([['Starting equity','10,000','Hypothetical USDT'],['Ending equity','11,280','After declared costs'],['Maximum drawdown','−8.4%','From prior equity peak'],['Observation range','181 days','1 Jan–30 Jun · UTC']])}<section class="j-card"><div class="j-section-title"><h3>Equity after declared costs</h3><span>USDT · synthetic illustration</span></div>${paths(exampleEquity)}<div class="j-section-title"><h3>Drawdown from the running peak</h3><span>Loss magnitude shown with signed labels</span></div>${paths(exampleDrawdown,{drawdown:true})}</section><div class="gate-explanation">Undefined metrics display “Unavailable” with a reason. Full hashes, execution assumptions and exact inputs remain attached to the archived run.</div>`,link('Compare baseline','comparison'));
  }else if(view==='trades'){
    page('Inspect the fills behind the result.','Run 013 · closed trades · UTC · hypothetical execution',`${filters(view)}<div class="j-two main-detail"><section class="j-card"><div class="j-section-title"><h3>Closed trades</h3><span>Selected: trade 042</span></div>${table(['Trade','Entry → exit · UTC','Direction','Net P&L','Costs'],[['041','12 Jun 08:00 → 12 Jun 19:00','Long','−6.20 USDT','0.82 USDT'],['<strong>042 · selected</strong>','14 Jun 09:00 → 14 Jun 18:00','Long','+7.88 USDT','0.82 USDT'],['043','16 Jun 03:00 → 16 Jun 12:00','Long','+3.14 USDT','0.81 USDT'],['044','18 Jun 02:00 → 18 Jun 15:00','Long','−2.93 USDT','0.80 USDT']])}<p class="j-fine">Four illustrative rows from an 84-trade design example. Signs and direction labels remain visible in opaque and reduced-effects modes.</p></section><aside class="j-card"><div class="row"><h2>Trade 042</h2>${badge('CLOSED · LONG')}</div><dl class="j-kv"><dt>Entry signal</dt><dd>14 Jun · 08:00 completed bar</dd><dt>Entry fill</dt><dd>09:00 next open · 62,210.00 USDT</dd><dt>Exit signal</dt><dd>17:00 completed bar</dd><dt>Exit fill</dt><dd>18:00 next open · 62,750.00 USDT</dd><dt>Quantity</dt><dd>0.016111 units</dd><dt>Gross P&L</dt><dd>+8.70 USDT</dd><dt>Total fees</dt><dd>0.81 USDT</dd><dt>Slippage cost</dt><dd>0.01 USDT</dd><dt>Net P&L</dt><dd>+7.88 USDT</dd></dl><p class="j-fine">Illustrative rounded values. This describes simulated fills and cannot execute an order.</p>${link('Inspect recorded assumptions','evidence')}</aside></div>`,link('Return to overview','results'));
  }else if(view==='empty'){
    page('The next step is yours.','Opening source does not create a report.',`<div class="gate-empty"><div class="j-card-icon">${icon('FlaskConical')}</div><h2>No completed experiment</h2><p>Your draft is available. Choose a verified dataset, capture the assumptions and run locally to create evidence.</p><div class="row">${link('Open strategy','studio',true)}${link('Choose a dataset','datasets')}</div></div><div class="j-three"><section class="j-card"><h3>No data selected</h3><p>Import and validate a file. Never replace unavailable market history with sample candles.</p>${link('Review import','import')}</section><section class="j-card"><h3>No runtime available</h3><p>Inspect runtime health. Your draft remains accessible while execution is unavailable.</p>${link('Inspect runtime','health')}</section><section class="j-card"><h3>No archived baseline</h3><p>Complete and preserve the first run before enabling comparison and robustness.</p><button class="button" disabled aria-describedby="empty-baseline">Compare baseline</button><small id="empty-baseline" class="gate-explanation">Requires a completed archived run.</small></section></div>`);
  }else if(view==='mixed-monitors'){
    page('Keep the workspace within reach.','Main window, detached editor and monitor recovery',`<div class="gate-monitor-pair"><section class="j-card"><div class="j-section-title"><h3>Monitor 1 · 1920×1080 physical</h3>${badge('100% SCALE')}</div><div class="gate-window"><div class="gate-window-title">ZTerminal — Market research</div><div class="gate-window-body"><div class="gate-rail">Chart<br>Research<br>Datasets</div><div class="gate-chart-thumb"><span>Primary chart · stable dark surface</span><div class="gate-trend"></div></div><div class="gate-context-thumb">Market context<br><br>Local verified data<br><br>Research report</div></div></div><p>Logical work area: 1920×1080 before taskbar insets.</p></section><section class="j-card"><div class="j-section-title"><h3>Monitor 2 · 2560×1440 physical</h3>${badge('150% SCALE')}</div><div class="gate-window detached"><div class="gate-window-title">Python Strategy · close to redock</div><div class="gate-window-body"><div class="gate-code-thumb"><code>import zterminal as zt<br><br>def strategy(data, params):<br>&nbsp;&nbsp;mean = zt.ema(data["close"], period=20)<br>&nbsp;&nbsp;return zt.Strategy(<br>&nbsp;&nbsp;&nbsp;&nbsp;entries=(data["close"] &lt; mean).fillna(False),<br>&nbsp;&nbsp;&nbsp;&nbsp;exits=(data["close"] &gt; mean).fillna(False))</code><p>Unsaved draft remains owned by the workspace.</p></div></div></div><p>Logical work area: approximately 1707×960 before taskbar insets.</p></section></div><div class="j-two"><section class="j-card"><h3>When the second monitor disappears</h3><p>Recover the detached editor into the surviving monitor’s work area. Preserve draft, selection and document identity. Show a recovery notice.</p><div class="gate-notice">${icon('Move')}Editor restored to this monitor. ${link('Redock editor','studio')}</div></section><section class="j-card"><h3>Docking does not duplicate work</h3><p>Move the presentation to a new window. Closing it returns the panel to its saved dock group. Symbol, timeframe, crosshair and replay linking are explicit opt-in settings.</p>${link('Review recovered workspace','recovery')}</section></div>`,link('Open detached example','detached'));
  }else if(view==='design-review'){
    const scenarios=[['Chart-led workspace','chart',1440,900,'rich'],['Focused source · real API','studio',1440,900,'rich'],['Equity & drawdown','equity',1440,900,'rich'],['Trade inspection','trades',1440,900,'rich'],['Bootstrap robustness','robustness',1440,900,'rich'],['Comparison · correct source','comparison',1440,900,'rich'],['No completed experiment','empty',1440,900,'rich'],['Reduced effects','chart',1440,900,'reduced'],['Opaque effects','chart',1440,900,'opaque'],['1366 physical at 150%','chart',911,512,'reduced'],['1366 physical at 200%','studio',683,384,'opaque'],['Compact configuration','configure',683,384,'opaque'],['Mixed monitors','mixed-monitors',1920,1080,'rich']];
    page('Review the native visual contract.','Prepared design source · Figma gate remains incomplete',`<div class="gate-review-note">Figma editing is currently blocked by the Starter tool quota. These local views are review material; they are not approved Figma components or implemented native capabilities.</div><div class="gate-review-grid">${scenarios.map(([label,route,w,h,e])=>`<a class="j-card gate-review-card" href="?view=${route}&width=${w}&height=${h}&effects=${e}"><h3>${label}</h3><span>${w}×${h} logical DIPs · ${e}</span><p>Open editable source preview →</p></a>`).join('')}</div>`);
  }
  // Connect detailed evidence without making a draft fabricate a completed run.
  const reportTabs=app.querySelector('.report-tabs');
  if(reportTabs)reportTabs.innerHTML=[['results','Overview'],['equity','Equity'],['trades','Trades'],['evidence','Evidence']].map(([route,label])=>`<button data-view="${route}" ${route===view?'aria-current="page"':''}>${label}</button>`).join('');
  app.querySelectorAll('.nav [data-view="calendar"], [aria-label="Economic calendar"]').forEach(b=>{
    b.disabled=true;b.title='Unavailable until a verified calendar data capability exists';
  });
  app.querySelectorAll('.nav button').forEach(b=>{const label=b.querySelector('b')?.textContent;if(label){b.setAttribute('aria-label',label);if(!b.disabled)b.title=label;}});
  if(app.querySelector('.sidebar.collapsed'))app.querySelector('[data-action="collapse"]')?.setAttribute('aria-label','Expand sidebar');
  // Prototype focus behavior; native UI Automation still requires native testing.
  let previousFocus=null,currentDialog=null;
  const focusDialog=()=>{
    const dialog=app.querySelector('[role="dialog"]');
    if(dialog===currentDialog)return;
    if(dialog){previousFocus=document.activeElement===document.body?app.querySelector('[aria-label="Terminal preferences"]'):document.activeElement;currentDialog=dialog;dialog.querySelector('button:not(:disabled),input:not(:disabled)')?.focus();}
    else {currentDialog=null;if(previousFocus?.isConnected)previousFocus.focus();previousFocus=null;}
  };
  new MutationObserver(focusDialog).observe(app,{childList:true,subtree:true});
  focusDialog();
  app.addEventListener('keydown',event=>{
    if(event.key!=='Tab'||!currentDialog)return;
    const items=[...currentDialog.querySelectorAll('button:not(:disabled),input:not(:disabled),a[href],[tabindex="0"]')].filter(n=>n.getClientRects().length);
    if(!items.length){event.preventDefault();return;}
    const first=items[0],last=items.at(-1);
    if(event.shiftKey&&(document.activeElement===first||!currentDialog.contains(document.activeElement))){event.preventDefault();last.focus();}
    else if(!event.shiftKey&&(document.activeElement===last||!currentDialog.contains(document.activeElement))){event.preventDefault();first.focus();}
  });
};
