# Native rebuild — implementation status

7 October 2026. The requested plan is active, with its Figma-first gate retained.

## Completed in this slice

- Updated the isolated design source to use `import zterminal as zt`, `strategy(data, params)` and `zt.Strategy`. EMA uses the actual `period` argument.
- Corrected robustness to closed-trade account-return bootstrap, independently sampled with replacement. Retained design-example labels and seed/algorithm annotations.
- Removed the incorrect implication that signal shifting proves arbitrary user Python causal. The configuration describes actual next-open semantics and the limitation.
- Added equity/drawdown, trade inspection, empty evidence, mixed-monitor recovery, reduced/opaque effects and a consolidated design review destination.
- Added 911×512 and 683×384 logical arrangements for a 1366×768 physical laptop at 150% and 200%. The editor uses a compact action row and configuration overlay; code and tables scroll within their panels.
- Named collapsed navigation controls, disabled the unavailable calendar, connected evidence sections, and added local prototype dialog focus containment and dismissal.
- Prepared `native-design-tokens.json`. This is a design specification, not implemented native resources or bound Figma variables.

## Evidence

Syntax checks pass for app.js, journeys.js and design-gate.js. Browser inspection covered seven arrangements, with no horizontal overflow in their app or dock bounds. Configuration focus wraps forward/backward and Escape dismisses it. Saved review images cover compact source, equity, trades and mixed monitors. `native-design-source-checks.json` records the bounded checks.

Equity and drawdown illustrations share the same synthetic path: starting equity 10,000, ending equity 11,280, maximum drawdown 8.4%. These are design illustrations, not archived results. Chart SVG paths are discrete editable geometry, not flattened full-screen images.

No claim is made that the Figma component/layer audit, all composed contrast checks, Narrator checks or native runtime tests have passed. Source arrangement checks are not mixed-DPI native-window tests.

## Blocking gate

The Figma access check returned **Starter MCP tool call limit**. Direct canvas reads/edits remain unavailable. The existing comparison frame 33:1080 still contains the wrong composition. No existing Figma screen was changed or replaced in this slice.

Remaining gate work: repair that frame, build revised screens from shared components and bound variables, inspect fonts/editability/bounds, wire Figma journeys, finish control-state variants and composed accessibility checks, then obtain design review.

Native milestones 1–6 remain unstarted because the accepted plan explicitly requires completing and reviewing Figma before coding. The native, Rust and Python application sources were not changed. Existing unrelated working-tree changes were preserved.

## Resume

1. Recheck direct Figma access once quota/access changes. Do not resubmit old capture IDs or import duplicate reference screens.
2. Use the existing component library and revised preview as references; finish the editable component-based Figma handoff.
3. Review the Figma gate before beginning native shell implementation.

Local review: http://127.0.0.1:8765/?view=design-review&width=1440&height=900
