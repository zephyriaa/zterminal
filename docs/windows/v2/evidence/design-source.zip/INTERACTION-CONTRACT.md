# V2 interaction and implementation contract

UI-first revision for review. The current web workstation supplies the information architecture; Geist and Violet supply its visual language. No application, engine, persistence, provider or broker capability was implemented in this directory.

## Shared presentation families to connect in Figma

| Family | Required properties / states | Source correspondence |
|---|---|---|
| Windows shell | Native title controls; global symbol; local workspace; utility actions | FloatingWorkstationShell + native title controls |
| Research navigation | Expanded 194px / rail 42px; selected, hover, focus, unavailable | ResearchSidebar, with planned local library entries |
| Dock group | Active / inactive tab; focus; detach; redock; close; dirty document | Dockview organization; native docking presentation model |
| Toolbar / icon button | Default, hover, pressed, focus, disabled; accessible label | Existing toolbar + Lucide vector source |
| Action / input | Primary / secondary; focus, error, disabled, loading | Existing UI control variants; reusable source helpers |
| Data badge | Live, cached, stale, gap, unavailable; text + icon | Provider / DatasetManifestV3 readiness |
| Evidence table | Numeric alignment, selection, loading, empty, unavailable | Immutable experiment artifact views |
| Dialog / inspector | Focus trap; Escape; persistent footer; scrollable content | Configure, indicators, appearance, instrument discovery |
| Diagnostics / job row | Queued, running, cancelled, failed, completed, interrupted | ExperimentRunV2; supervised worker lifecycle |

Use the existing Figma library as the starting point. Load current text fonts and inspect real Geist style names before editing. Replace old Inter / JetBrains Mono styles intentionally. Bind Violet semantic variables, spacing and radius variables to actual instances. Raw captures are visual references and must be replaced only after instance-based compositions pass review; do not delete references prematurely.

## Journey wiring

| Start | Actions and destinations | Truthful state boundary |
|---|---|---|
| First launch | Choose import → validate → dataset catalog → open local chart | No account; no preselected live instrument |
| Workspace library | Select draft → editor; select archive → report | A draft never generates an invented report |
| Editor | Configure → capture revision / exact inputs → queued / running → completed report | Running, failed and cancelled do not expose final metrics |
| Import rejection | Inspect issues → export diagnostics → correct a copy → validate again | Original file retained; no invalid manifest enters catalog |
| Archived result | Inspect assumptions / provenance → compare baseline → robustness | Only completed results; mismatched inputs require a warning |
| Replay | Start → pause / play → step completed bar → boundary → stop | Chart and calculations share ReplayClock; future bars withheld |
| Panel | Resize → detach → close/redock → restore workspace | Closing the detached window returns content, including unsaved drafts |
| Recovery | Inspect valid / rejected records → restore verified content | Preserve original journals; recover off-screen windows visibly |

The local source contains linked design scenarios for these destinations. It does not perform jobs or imports. Figma prototype links are still pending direct editing access. Job scenarios and archived runs are separate destinations; selecting an archived report does not complete the running scenario.

## Canonical data contracts and readiness

| View / control | Domain contract | Milestone / availability |
|---|---|---|
| Workspace library, drafts, restoration | WorkspaceDocumentV2 + StrategyRevisionV2 | Durable workspaces |
| Instrument, chart, studies, drawings | ChartDocumentV3 + verified provider metadata | Data and chart workflows |
| Import, coverage, validation, source hashes | DatasetManifestV3 | Data and chart workflows |
| Configure, supervised worker, cancellation | ExperimentRunV2 + StrategyRevisionV2 | Research studio |
| Report, comparison, robustness, export | Immutable ExperimentRunV2 artifacts | Evidence and robustness |
| Playback and availability cursor | ReplayClock | Data and chart workflows |
| Docking, monitor placement, material mode | Native presentation models only | Native shell / durable workspaces |

Existing native interfaces still require adapters and UI integration. A design badge reading “Available” illustrates a capability state; implementation must validate native readiness before enabling it. Provider discovery remains disabled without verified adapter metadata. AI, order flow, options/GEX and cloud sync remain later roadmap work.

## Desktop sizing and Windows scaling

Design dimensions are logical pixels / DIPs. Capture sizes are 1366×768, 1440×900, 1920×1080 and a 1024×680 detached arrangement. Scaling converts logical size to physical size: a 1440×900 logical canvas occupies 2160×1350 physical pixels at 150%, or 2880×1800 at 200%.

Do not treat a 1366×768 physical laptop at 200% as a 1366×768 logical viewport. Below the compact logical size, collapse the sidebar to its 42px rail, use one active dock group with tabs, and move configuration into an overlay; those additional high-DPI compact compositions remain a design gate. Respect the monitor work area, preserve logical dimensions and clamp restored placement when monitors disappear. Mixed-DPI placement and Direct3D device recovery require native runtime checks after UI review.

Long library / diagnostics content scrolls inside its panel. Modal actions remain in a fixed footer. Do not shrink research text to force an entire archive on one screen. Compact source checks found no horizontal overflow in configuration, jobs, comparison or replay. Full Figma clipping and all compact states remain unaudited while direct reads are blocked.

## Materials, accessibility and motion

Use #090A10 workspace, #14111D panels, #0B0A10 plot, #B5A2E8 selection, #F0EFF5 text and #A8A2B5 muted text. Keep green / rose direction separate from selection and include signs, labels and state words.

Glass belongs in chrome and controls. Reading surfaces remain stable and dark; do not require backdrop acrylic over SwapChainPanel. Opaque mode removes transparency and luminous effects. Reduced effects retain hierarchy through fills, separators and focus outlines. Reduced motion removes decorative movement; functional feedback may use 120–200ms transitions.

Keyboard focus uses a 2px Violet outline with offset. Dialogs must trap focus, restore it on dismissal, and expose their title. Prototype overlays currently support Escape but do not constitute a verified production focus trap. Table labels and controls need native accessibility names, keyboard navigation, and contrast checks at their actual composed surfaces.

## Remaining acceptance gates

- Direct Figma editing is blocked by the connected Starter tool quota. Shared component integration, variable binding and Figma prototype wiring cannot yet be executed.
- Audit native node types, rendered fonts, image fills and bounds for every capture. The source is semantic DOM with editable text and chart geometry; only the discrete Z mark is a bitmap. Do not infer all Figma layer properties solely from source checks.
- Replace reference captures with shared instances and update the earlier eight compositions with local library destinations. Preserve the original 35-screen draft as earlier work until replacements pass review.
- Finish detailed equity / drawdown, trade inspection, empty states, opaque / reduced material variants, high-DPI compact arrangements and mixed-monitor compositions in the revised visual language.
- Complete contrast, assistive-technology and keyboard audits. Review the connected Figma journeys before native implementation begins.

This document is a prepared handoff, not a claim that the Figma or native release gate has passed.
